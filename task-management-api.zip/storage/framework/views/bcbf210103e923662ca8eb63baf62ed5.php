<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Task Notification</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: #3b82f6; color: white; padding: 20px; text-align: center; }
        .content { background: #f9fafb; padding: 20px; border-radius: 0 0 5px 5px; }
        .task-info { background: white; padding: 15px; border-radius: 5px; margin: 15px 0; }
        .status { display: inline-block; padding: 5px 10px; border-radius: 15px; font-size: 12px; font-weight: bold; }
        .status-pending { background: #fef3c7; color: #92400e; }
        .status-in_progress { background: #dbeafe; color: #1e40af; }
        .status-completed { background: #d1fae5; color: #065f46; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Task Management System</h1>
        </div>
        <div class="content">
            <h2>Task <?php echo e(ucfirst($action)); ?></h2>
            <p>Hello <?php echo e($user->name); ?>,</p>
            
            <div class="task-info">
                <h3><?php echo e($task->title); ?></h3>
                <p><strong>Description:</strong> <?php echo e($task->description); ?></p>
                <p><strong>Status:</strong> 
                    <span class="status status-<?php echo e($task->status); ?>">
                        <?php echo e(str_replace('_', ' ', ucfirst($task->status))); ?>

                    </span>
                </p>
                <?php if($task->due_date): ?>
                <p><strong>Due Date:</strong> <?php echo e($task->due_date->format('M j, Y g:i A')); ?></p>
                <?php endif; ?>
                <p><strong>Assigned To:</strong> <?php echo e($task->user->name); ?></p>
            </div>

            <p>
                <?php if($action === 'created'): ?>
                You can view and manage this task in your dashboard.
                <?php elseif($action === 'completed'): ?>
                This task has been successfully completed.
                <?php else: ?>
                This task has been updated. Please review the changes.
                <?php endif; ?>
            </p>

            <p>
                <a href="<?php echo e(url('/tasks/' . $task->id)); ?>" style="background: #3b82f6; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">
                    View Task
                </a>
            </p>

            <p>Best regards,<br>Task Management System</p>
        </div>
    </div>
</body>
</html><?php /**PATH D:\Laravel Projects\task-management-api\resources\views\emails\task-notification.blade.php ENDPATH**/ ?>